/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-15     Yifang       the first version
 */
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <onenet.h>

#define DBG_LEVEL DBG_INFO
#define DBG_SECTION_NAME  "upload_info"
#include <rtdbg.h>

#include "data_upload.h"

static float temp_upload_data, humi_upload_data, lux_upload_data, bmp_upload_data;

enum weather_index
{
    TEMP_INDEX,
    HUMI_INDEX,
    LUX_INDEX,
    BMP_INDEX
};

struct WEATHER_STRUCT
{
    enum weather_index index;
    const char *data_stream_name;
    float val;
};

struct WEATHER_STRUCT weather_upload_struct[] =
{
    {TEMP_INDEX, "temperature", 0},
    {HUMI_INDEX, "humidity", 0},
    {LUX_INDEX, "lux", 0},
    {BMP_INDEX, "bmp", 0}
};

void weather_task_entry(void)
{
    while (1)
    {
//        LOG_I("----------------- Meteorological data collection task started -------------------");
        // ��ȡ�¶ȡ�ʪ����ֵ
        struct DHT11_DATA dht11_upload_struct = dht11_read();
        weather_upload_struct[TEMP_INDEX].val = dht11_upload_struct.templature;
        weather_upload_struct[HUMI_INDEX].val = dht11_upload_struct.humidity;

        // ��ȡ��ѹ��ֵ
        weather_upload_struct[BMP_INDEX].val = bmp280_read();

        // ��ȡ������Ϣ��ֵ
        weather_upload_struct[LUX_INDEX].val = bh1750_read();

        // ��ӡ���ݲɼ�������Ϣ
        for(int i = 0; i < 4; i++)
        {
//            LOG_I("<%s>: %f",weather_upload_struct[i].data_stream_name,weather_upload_struct[i].val);
        }

//        LOG_I("-------------- The meteorological data collection task is terminated ------------");

        rt_thread_mdelay(20000);
    }
}

/* upload random value to temperature */
static void onenet_upload_entry(void *parameter)
{
    while (1)
    {
        for (int i = 0; i < sizeof(weather_upload_struct) / sizeof(weather_upload_struct[0]); i++)
        {
            if (onenet_mqtt_upload_digit(weather_upload_struct[i].data_stream_name, weather_upload_struct[i].val) < 0)
            {
                LOG_E("upload has an error, stop uploading");
                break;
            }
            else
            {
                LOG_I("buffer : {\"%s\":%f}", weather_upload_struct[i].data_stream_name, weather_upload_struct[i].val);
            }

            rt_thread_delay(rt_tick_from_millisecond(5 * 1000));
        }
    }
}

int onenet_upload_cycle(void)
{
    rt_thread_t onenet_thread;
    rt_thread_t weather_thread;

    onenet_thread = rt_thread_create("onenet_th", onenet_upload_entry, RT_NULL, 2048, 23, 500);
    weather_thread = rt_thread_create("weather_th", weather_task_entry, RT_NULL, 2048, 22, 500);
    if (onenet_thread != RT_NULL && weather_thread != RT_NULL)
    {
        rt_thread_startup(onenet_thread);
        rt_thread_startup(weather_thread);
    }

    return 0;
}
MSH_CMD_EXPORT(onenet_upload_cycle, send data to OneNET cloud cycle);


int onenet_publish_digit(int argc, char **argv)
{
    if (argc != 3)
    {
        LOG_E("onenet_publish [datastream_id]  [value]  - mqtt pulish digit data to OneNET.");
        return -1;
    }

    if (onenet_mqtt_upload_digit(argv[1], atoi(argv[2])) < 0)
    {
        LOG_E("upload digit data has an error!\n");
    }

    return 0;
}
MSH_CMD_EXPORT_ALIAS(onenet_publish_digit, onenet_mqtt_publish_digit, send digit data to onenet cloud);

int onenet_publish_string(int argc, char **argv)
{
    if (argc != 3)
    {
        LOG_E("onenet_publish [datastream_id]  [string]  - mqtt pulish string data to OneNET.");
        return -1;
    }

    if (onenet_mqtt_upload_string(argv[1], argv[2]) < 0)
    {
        LOG_E("upload string has an error!\n");
    }

    return 0;
}
MSH_CMD_EXPORT_ALIAS(onenet_publish_string, onenet_mqtt_publish_string, send string data to onenet cloud);

/* onenet mqtt command response callback function */
static void onenet_cmd_rsp_cb(uint8_t *recv_data, size_t recv_size, uint8_t **resp_data, size_t *resp_size)
{
    char res_buf[] = { "cmd is received!\n" };

    LOG_D("recv data is %.*s\n", recv_size, recv_data);

    /* user have to malloc memory for response data */
    *resp_data = (uint8_t *) ONENET_MALLOC(strlen(res_buf));

    strncpy((char *)*resp_data, res_buf, strlen(res_buf));

    *resp_size = strlen(res_buf);
}

/* set the onenet mqtt command response callback function */
int onenet_set_cmd_rsp(int argc, char **argv)
{
    onenet_set_cmd_rsp_cb(onenet_cmd_rsp_cb);
    return 0;
}
MSH_CMD_EXPORT(onenet_set_cmd_rsp, set cmd response function);
