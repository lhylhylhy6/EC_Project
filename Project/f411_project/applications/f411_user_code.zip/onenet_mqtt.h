/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-13     瓜子的皮       the first version
 */
#ifndef APPLICATIONS_ONENET_MQTT_H_
#define APPLICATIONS_ONENET_MQTT_H_

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "rtthread.h"
#include <onenet.h>
#include "stdio.h"
#include "string.h"
#include <string.h>
#include <rtdbg.h>


//mqtt需要联网     确保在网络连接后再使用函数
//mqtt需要联网     确保在网络连接后再使用函数
//mqtt需要联网     确保在网络连接后再使用函数

void mqtt_up_data_start();//上报云端线程启动
void mqtt_up_GPS(char* str);//上报数据 上报线程会持续上报值 如果想停止持续上报 可以上报后传入RT_NULL
void mqtt_up_device_message(char* str);
void mqtt_up_speed(int val);
void mqtt_up_temperature(int val);
void mqtt_up_humidity(int val);
void mqtt_up_air_pressure(int val);
void mqtt_up_air_quality(int val);
void mqtt_up_data_stop();//上报云端线程关闭

void mqtt_recv_data_start();
void mqtt_recv_data_stop();

#endif /* APPLICATIONS_ONENET_MQTT_H_ */
