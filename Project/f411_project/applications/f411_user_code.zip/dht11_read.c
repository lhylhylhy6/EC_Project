/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-13     Yifang       the first version
 */
#include <rtthread.h>
#include "stm32f4xx.h"
#include <board.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "dht11_lib/dht11.h"
#include "dht11_read.h"

#define DBG_LEVEL DBG_INFO
#define DBG_SECTION_NAME  "dht_info"
#include <rtdbg.h>

static uint8_t temperature = 1;                     //�¶�ֵ
static uint8_t humidity = 1;                        //ʪ��ֵ

char* CntState = "No Connect";          //����״̬
uint8_t aTxBuffer[50];                       //��ӡ��Ϣ
struct DHT11_DATA  dht11_struct;

void dht11_drv_init(void)
{
    MX_TIM5_Init();
    MX_GPIO_Init();

    DHT11_Rst();                                   //��λDHT11
    while(DHT11_Check())                           //���DHT11����
    {
        LOG_E("%s\n",CntState);
        rt_thread_mdelay(500);
    }
    CntState = "Connected";
    LOG_I("[weather] dht11_drv_init success! %s\r\n",CntState);
}
INIT_APP_EXPORT(dht11_drv_init);

float rand_data_generate(float minData, float maxData) {
    // ����0��1֮��������
    float random = (float)rand() / RAND_MAX;

    // �������ӳ�䵽ָ����Χ
    float rand_data_range = maxData - minData;
    float result_rand_data = (random * rand_data_range) + minData;

    return result_rand_data;
}

struct DHT11_DATA  dht11_read(void)
{
    struct DHT11_DATA dht11_struct;

//    /******************************************/
    float minTemperature = 19.00;   // ��С�¶�
    float maxTemperature = 20.00;    // ����¶�

    float minHumidity = 70.00;   // ��С�¶�
    float maxHumidity = 80.00;    // ����¶�

    // ʹ�õ�ǰʱ����Ϊ��������ɵ�����
    srand(rt_tick_get());

    // ��������¶�ֵ
    dht11_struct.templature = rand_data_generate(minTemperature, maxTemperature);
    dht11_struct.humidity = rand_data_generate(minHumidity, maxHumidity);
    /******************************************/

    LOG_I("temperature : %f, humidity : %f %% \r\n", dht11_struct.templature, dht11_struct.humidity);

    return dht11_struct;

//    DHT11_Read_Data(&humidity,&temperature);                        //������ʪ�ȵ�ֵ
//    humidity = dht11_struct.humidity;
//    temperature = dht11_struct.templature;
//    LOG_I("temperature : %f, humidity : %f %% \r\n",temperature,humidity);
//
//    return dht11_struct;
}
MSH_CMD_EXPORT(dht11_read,dht11_read);




