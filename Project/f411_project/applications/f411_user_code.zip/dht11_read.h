/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-14     Yifang       the first version
 */
#ifndef APPLICATIONS_DHT11_READ_H_
#define APPLICATIONS_DHT11_READ_H_

struct DHT11_DATA
{
    float templature;
    float humidity;
};

struct DHT11_DATA  dht11_read(void);

#endif /* APPLICATIONS_DHT11_READ_H_ */
