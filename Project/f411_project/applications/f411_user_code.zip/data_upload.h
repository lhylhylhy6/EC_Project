/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-15     Yifang       the first version
 */
#ifndef APPLICATIONS_DATA_UPLOAD_H_
#define APPLICATIONS_DATA_UPLOAD_H_

#include "bh1750_config.h"
#include "bmp280_read.h"
#include "dht11_read.h"

struct DHT11_DATA   dht11_upload_struct;

#endif /* APPLICATIONS_DATA_UPLOAD_H_ */
