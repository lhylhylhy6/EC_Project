/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-13     瓜子的皮       the first version
 */

#include "onenet_mqtt.h"

//接收消息
static void onenet_cmd_rsp_cb(uint8_t *recv_data, size_t recv_size,uint8_t **resp_data,size_t *resp_size)
{
  /* 申请内存 */

  /* 解析命令 */
    rt_kprintf("%s\n",recv_data);//打印接收到的命令
  /* 执行动作 */

  /* 返回响应 */

}

void mqtt_recv_data_start()
{
    onenet_set_cmd_rsp_cb(onenet_cmd_rsp_cb);//设置接收回调函数
}

MSH_CMD_EXPORT(mqtt_recv_data_start,mqtt_recv_data_start);
void mqtt_recv_data_stop()
{
    onenet_set_cmd_rsp_cb(NULL);//设置接收回调函数
}
MSH_CMD_EXPORT(mqtt_recv_data_stop,mqtt_recv_data_stop);
