/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-07-13     瓜子的皮       the first version
 */
#include "onenet_mqtt.h"
static char* Mqtt_Up_Device_Message = RT_NULL;
//static int Mqtt_Up_Speed =-1 ;
static char* Mqtt_Up_GPS_Data = RT_NULL;
//static int Mqtt_Up_Temperature = -1;
//static int Mqtt_Up_Humidity = -1;
//static int Mqtt_Up_Air_Pressure = -1;
//static int Mqtt_Up_Air_Quality = -1;

static int Mqtt_Up_Speed = 55 ;
static int Mqtt_Up_Temperature = -55;
static int Mqtt_Up_Humidity = 55;
static int Mqtt_Up_Air_Pressure = 55;
static int Mqtt_Up_Air_Quality = 55;

static int g_up_thread_flag = 1;

//上传数据
static void up_data_thread_entry(void *parameter)
{
    while(g_up_thread_flag)
    {
        rt_thread_mdelay(100);
        if(Mqtt_Up_Speed != -1) onenet_mqtt_upload_digit("speed",Mqtt_Up_Speed);
        rt_thread_mdelay(100);
        if(Mqtt_Up_Device_Message != RT_NULL) onenet_mqtt_upload_string("Device_Message",Mqtt_Up_Device_Message);
        rt_thread_mdelay(100);
        if(Mqtt_Up_GPS_Data != RT_NULL) onenet_mqtt_upload_string("GPS_Data",Mqtt_Up_GPS_Data);
        rt_thread_mdelay(100);
        if(Mqtt_Up_Temperature != -1) onenet_mqtt_upload_digit("Temperature",Mqtt_Up_Temperature);
        rt_thread_mdelay(100);
        if(Mqtt_Up_Humidity != -1) onenet_mqtt_upload_digit("Humidity",Mqtt_Up_Humidity);
        rt_thread_mdelay(100);
        if(Mqtt_Up_Air_Pressure != -1) onenet_mqtt_upload_digit("Air_Pressure",Mqtt_Up_Air_Pressure);
        rt_thread_mdelay(100);
        if(Mqtt_Up_Air_Quality != -1) onenet_mqtt_upload_digit("Air_Quality",Mqtt_Up_Air_Quality);
    }
}

void mqtt_up_GPS(char* str)
{
    Mqtt_Up_GPS_Data = str;
}
void mqtt_up_speed(int val)
{
    Mqtt_Up_Speed = val;
}

void mqtt_up_device_message(char* str)
{
    Mqtt_Up_Device_Message = str;
}

void mqtt_up_temperature(int  val)
{
    Mqtt_Up_Temperature = val;
}

void mqtt_up_humidity(int val)
{
    Mqtt_Up_Humidity = val;
}

void mqtt_up_air_pressure(int val)
{
    Mqtt_Up_Air_Pressure = val;
}

void mqtt_up_air_quality(int val)
{
    Mqtt_Up_Air_Quality = val;
}

void mqtt_up_data_start()
{
    rt_thread_t thread = rt_thread_create("up_data",up_data_thread_entry, RT_NULL, 4096, 25, 10); /* 创建 serial 线程 */

    /* 创建成功则启动线程 */
    if (thread != RT_NULL)
    {
        g_up_thread_flag =1;
        rt_thread_startup(thread);
    }
}
//MSH_CMD_EXPORT(mqtt_up_data_start,mqtt_up_data_start);
INIT_APP_EXPORT(mqtt_up_data_start);

void mqtt_up_data_stop()
{
    g_up_thread_flag = 0;
}
